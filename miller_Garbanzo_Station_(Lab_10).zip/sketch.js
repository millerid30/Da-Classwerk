var song;

function preload() {
  song = loadSound("song.mp3");
  static = loadSound("static.mp3");
  radio = loadImage("radio.webp");
}

function setup() {
  cnv = createCanvas(400, 400);
  cnv.mousePressed(press);
  textSize(24);
  static.play();
  image(radio,200,200,100,100);
  outputVolume(0.5);
}
function press() {
  song.loop();
  static.pause();
  background(250);
  image(radio,190,180,120,120);
  text('Music Time', 190, 175);
}
function mouseReleased() {
  song.pause();
  static.loop();
  background(250);
  image(radio,200,200,100,100);
}
