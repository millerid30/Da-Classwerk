const CANVAS_WIDTH = 600;
const CANVAS_HEIGHT = 450;
let ms;
let pc;

function preload() {
  ms = loadImage('Mouse.png');
  pc = loadImage('DesktopCrunchy.png');
}

function setup() {
  createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT);
  colorMode(RGB,255,255,255,1);
  textFont('Tahoma');
  textSize(12);
  noCursor();
}

function draw() {
  background(220);
  image(pc,0,0,600,450);
  
  stroke(0);
  strokeWeight(2);
  fill(255);
  text('trash',10,20);
  text('internet\nexplorer',10,60);
  text('"homework"',10,115);
  text('minecraft',10,155);
  text('computer bombooter',10,185,75,25);
  text('start',20,446);
  text('12:00',565,446);
  
  if(mouseIsPressed === true) {
    image(ms,mouseX-12,mouseY,30,25);
  } else {
    image(ms,mouseX-12,mouseY-5,30,30);
  }
}