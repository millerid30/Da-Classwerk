const CANVAS_WIDTH = 600;
const CANVAS_HEIGHT = 600;

function setup() {
  createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT);
  colorMode(RGB,255,255,255,1);
  angleMode(DEGREES);
  ellipseMode(RADIUS);
  rectMode(RADIUS);
}

function storm(x,y) {
  push();
  
  translate(x,y);
  scale(random(0.25,1.25))
  rotate(random(-30,30));
  
  strokeWeight(2);
  beginShape(); // Lightning Bolt
  fill(255,255,0);
  vertex(0,0);
  vertex(5,-20);
  vertex(-5,-20);
  vertex(0,-40);
  vertex(15,-40);
  vertex(10,-30);
  vertex(20,-30);
  vertex(0,0);
  endShape();
  
  beginShape(); // Storm Cloud
  fill(150,150,150);
  vertex(35,-40);
  vertex(-30,-40);
  bezierVertex(-45,-50,-25,-65,-25,-60);
  bezierVertex(-35,-80,0,-90,5,-80);
  bezierVertex(25,-90,35,-65,30,-60);
  bezierVertex(50,-55,40,-40,35,-40);
  endShape();
  
  pop();
}

function draw() {
  background(25,50,150);
  stroke(30);
  strokeWeight(2.5);
  beginShape();
  fill(5,175,30);
  ellipse(300,300,200,175);
  endShape();
  
  for(let i = 0; i < 10; i++) {
    storm(random(125,475),random(175,475));
  }

  
  
  
  
  
  stroke(255,255,255);
  fill(255,0,0)
  textSize(50);
  text('Weather Map',155,45);
  text('(You are screwed)',115,580);
  noStroke();
}